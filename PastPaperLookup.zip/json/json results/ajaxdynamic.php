<?php 


	function checkIfExists($namesarray,$searchterm){
		$existingname = ""; //This will hold the results. Initially zero

		foreach ($namesarray as $name) {
			//Convert the name to be lowercase
			$name = strtolower($name);

			//Get the length of the search term. You need to check a name e.g 
			//if I search Ti, then i want names starting from T then followed by i
			
			$searchLength = strlen($searchterm);

			//Get substing of size n e.g. if To is the search term, then get all first letters. Eg in names array, Ti, Ti, Ma, and Ju, 
			$substringname = substr($name, 0, $searchLength);


			if(stristr($searchterm, $substringname)){
				//Create the Search hints
				if($existingname==""){
					$existingname = $name;
				}else{
					$existingname.=",";
					$existingname.= $name;
				}
			}
		}

		return $existingname;
	}




	$names = array("Titus","Timothy","Mary","Judy","Peter","Lucile");

	$search_val = $_GET['search_val'];
	if(strlen($search_val)<=0){
		echo json_encode("");
	}else{


		$existingnames =  checkIfExists($names,$search_val);
		
		echo json_encode($existingnames);
	}

	

?>