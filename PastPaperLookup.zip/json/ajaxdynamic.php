<?php


	function checkIfExists($namesarray,$searchterm){
		$existingname = ""; //This will hold the results. Initially zero

		foreach ($namesarray as $name) {
			//Convert the name to be lowercase
			//$name = strtolower($name);

			//Get the length of the search term. You need to check a name e.g
			//if I search Ti, then i want names starting from T then followed by i

			$searchLength = strlen($searchterm);

			//Get substing of size n e.g. if To is the search term, then get all first letters. Eg in names array, Ti, Ti, Ma, and Ju,
			$substringname = substr($name, 0, $searchLength);


			if(stristr($searchterm, $substringname)){
				//Create the Search hints
				if($existingname==""){
					$existingname = $name;
				}else{
					$existingname.=",";
					$existingname.= $name;
				}
			}
		}

		return $existingname;
	}




	$names = array("Titus","Timothy","Mary","Judy","Calvin","Lucile");
	$papersALevel = array(
		"Luganda-P1-2016",
		"History-P6-2019",
		"Luganda-P2-2013",
		"Luganda-P3-2013",
		"History-P3-2018",
		"History-P1-2016",
		"History-P3-2016",
		"History-P6-2016",
		"History-P1-2013",
		"History-P3-2013",
		"History-P6-2013",
		"History-P1-2012",
		"CRE-P1-2016",
		"CRE-P2-2016",
		"CRE-P1-2013",
		"CRE-P2-2013",
		"CRE-P4-2013",
		"Art-P1-2016",
		"Art-P2-2016",
		"Art-P1-2013",
		"Literature-P1-2016",
		"Entrepreneurship-P1-2018",
		"Entrepreneurship-P2-2018",
		"Entrepreneurship-P3-2018",
		"Physics-P1-2016",
		"Physics-P2-2016",
		"Physics-P3-2016",
		"Physics-P3-2013",
		"Math-P1-2016",
		"Math-P2-2016",
		"Math-P1-2013",
		"Math-P2-2013",
		"Chemistry-P3-2016",
		"Sub-ICT-P1-2016",
		"General Paper-P1-2019",
		"General Paper-P1-2018",
		"General Paper-P1-2013",
		"History-P3-2019",
		"CRE-P2-2019",
		"CRE-P3-2019",
		"CRE-P4-2019",
		"Economics-P1-2016",
		"Economics-P2-2016",
		"Economics-P1-2013",
		"Economics-P2-2013",
		"Sub-Math-P1-2016",
		"Sub-Math-P1-2013",
		"Biology-P3-2016",
		"Biology-P1-2013",
		"Biology-P2-2013",
		"IRE-P1-2019",
		"IRE-P2-2019",
		"IRE-P3-2019",
		"Chemistry-P3-2012",
		"Art-P2-2019",
		"Art-P3-2019",
		"Math-P1-2017",
		"Math-P2-2017",
		"Math-P1-2012",
		"Math-P2-2012",
		"Literature-P1-2019",
		"Literature-P2-2019",
		"Economics-P1-2019",
		"Economics-P1-2012",
		"Economics-P2-2012",
		"CRE-P1-2019",
		"CRE-P4-2018",
		"CRE-P1-2012",
		"CRE-P2-2012",
		"CRE-P4-2012",
		"Foods And Nutrition-P1-2019",
		"Foods And Nutrition-P2-2019",
		"Biology-P1-2012",
		"Biology-P2-2012",
		"Biology-P3-2012",
		"Geography-P2-2018",
		"Geography-P1-2012",
		"Geography-P2-2012",
		"Geometrical & Building Drawing-P1-2019",
		"Geometrical & Building Drawing-710/2-P2-2019",
		"Geometrical & Building Drawing-720/2-P2-2019",
		"General Paper-P1-2012",
		"Physics-P1-2012",
		"Physics-P2-2012",
		"History-P1-2019",
		"History-P1-2018",
		"Chemistry-P3-2014",
		"History-P6-2012",
		"Luganda-P1-2019",
		"Luganda-P2-2019",
		"Luganda-P3-2019",
		"Luganda-P1-2018",
		"Luganda-P2-2018",
		"Luganda-P3-2018",
		"Luganda-P2-2012",
		"Entrepreneurship-P1-2019",
		"Entrepreneurship-P2-2019",
		"Entrepreneurship-P3-2019",
		"Entrepreneurship-P1-2012",
		"Foods And Nutrition-P1-2018",
		"Foods And Nutrition-P2-2018",
		"Sub-ICT-P1-2018",
		"Sub-ICT-P3-2018",
		"Sub-ICT-P1-2014",
		"Entrepreneurship-P1-2014",
		"Entrepreneurship-P2-2014",
		"Entrepreneurship-P3-2014",
		"Geography-P1-2014",
		"Geography-P2-2014",
		"Geography-P3-2014",
		"Economics-P2-2019",
		"Economics-P1-2014",
		"General Paper-P1-2014",
		"Sub-Math-P1-2019",
		"Sub-Math-P1-2018",
		"Sub-Math-P1-2014",
		"Physics-P1-2019",
		"Physics-P1-2018",
		"Physics-P2-2018",
		"Physics-P3-2018",
		"Physics-P1-2014",
		"Physics-P2-2014",
		"Physics-P3-2014",
		"Math-P1-2019",
		"Math-P2-2019",
		"Math-P1-2018",
		"Math-P2-2018",
		"Literature-P2-2018",
		"Literature-P3-2018",
		"Literature-P1-2014",
		"Literature-P2-2014",
		"Literature-P3-2014",
		"CRE-P1-2014",
		"CRE-P2-2014",
		"CRE-P4-2014",
		"Chemistry-P2-2019",
		"Chemistry-P2-2018",
		"Chemistry-P2-2016",
		"Chemistry-P1-2014",
		"Chemistry-P2-2014",
		"Biology-P2-2019",
		"Biology-P1-2014",
		"Biology-P2-2014",
		"Biology-P3-2014",
		"Luganda-P1-2014",
		"Luganda-P2-2014",
		"Luganda-P3-2014",
		"Agriculture-P1-2014",
		"Agriculture-P2-2014",
		"History-P1-2014",
		"History-P3-2014");

	$search_val = $_GET['search_val'];
	if(strlen($search_val)<=0){
		echo json_encode("No matches found");
	}else{


		$existingnames =  checkIfExists($papersALevel,$search_val);

		#echo json_encode($existingnames);
		if (strlen($existingnames)>0) {
			$counter = 1;
			echo('</br>'.$counter.'. ');
			$counter++;
			for ($i=0; $i < strlen($existingnames); $i++) {
				$varLetter = $existingnames[$i];
				if ($varLetter == ',') {
					echo('</br>');
					echo($counter.'. ');
					$counter++;
				} else{
					echo ($varLetter);
				}
			}
		} else{
				echo('</br>No matches found');
		}
	}



?>
