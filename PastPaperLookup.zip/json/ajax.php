<?php 

	$titus = array('firstname'=>'Titus','lastName'=>'Tunduny','email'=>'ttunduny@strathmore.edu');
	$kevin = array('firstname'=>'Kevin','lastName'=>'Omondi','email'=>'komondi@strathmore.edu');
	$eunice = array('firstname'=>'Eunice','lastName'=>'Manyasi','email'=>'emanyasi@strathmore.edu');
	
	$person = array($titus,$kevin,$eunice);

	$people_details = array('size'=>sizeof($person),
							'details'=>$person);


	echo json_encode($people_details);



?>