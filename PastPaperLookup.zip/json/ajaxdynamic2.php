<?php


	function checkIfExists($namesarray,$searchterm){
		$existingname = ""; //This will hold the results. Initially zero

		foreach ($namesarray as $name) {
			//Convert the name to be lowercase
			//$name = strtolower($name);

			//Get the length of the search term. You need to check a name e.g
			//if I search Ti, then i want names starting from T then followed by i

			$searchLength = strlen($searchterm);

			//Get substing of size n e.g. if To is the search term, then get all first letters. Eg in names array, Ti, Ti, Ma, and Ju,
			$substringname = substr($name, 0, $searchLength);


			if(stristr($searchterm, $substringname)){
				//Create the Search hints
				if($existingname==""){
					$existingname = $name;
				}else{
					$existingname.=",";
					$existingname.= $name;
				}
			}
		}

		return $existingname;
	}




	$names = array("Titus","Timothy","Mary","Judy","Calvin","Lucile");
	$papersOLevel = array(
    "Physics-P1-2017",
    "Physics-P4-2017",
    "Chemistry-P1-2017",
    "Chemistry-P3-2017",
    "Chemistry-P1-2015",
    "Chemistry-P2-2015",
    "Chemistry-P3-2015",
    "Chemistry-P4-2015",
    "Commerce-P1-2019",
    "Commerce-P1-2017",
    "Commerce-P1-2015",
    "Biology-P1-2017",
    "Biology-P1-2015",
    "Biology-P3-2015",
    "Art-P1-2017",
    "Art-P3-2015",
    "Art-P5-2015",
    "Geography-P1-2015",
    "Geography-P2-2015",
    "Literature-P1-2017",
    "Literature-P1-2015",
    "CRE-P1-2017",
    "CRE-P1-2017",
    "CRE-P1-2015",
    "Political Education-P2-2015",
    "Physics-P2-2015",
    "Physics-P4-2015",
    "History-P1-2017",
    "History-P4-2017",
    "History-P1-2015",
    "History-P2-2015",
    "IRE-P1-2017",
    "IRE-P2-2015",
    "Lugha Ya Kiswahili-P1-2017",
    "Lugha Ya Kiswahili-P1-2015",
    "Agriculture-P1-2017",
    "Agriculture-P2-2017",
    "Luganda-P1-2017",
    "History-P2-2018",
    "History-P4-2018");

	$search_val = $_GET['search_val'];
	if(strlen($search_val)<=0){
		echo json_encode("No matches found");
	}else{


		$existingnames =  checkIfExists($papersOLevel,$search_val);

		#echo json_encode($existingnames);
		if (strlen($existingnames)>0) {
			$counter = 1;
			echo('</br>'.$counter.'. ');
			$counter++;
			for ($i=0; $i < strlen($existingnames); $i++) {
				$varLetter = $existingnames[$i];
				if ($varLetter == ',') {
					echo('</br>');
					echo($counter.'. ');
					$counter++;
				} else{
					echo ($varLetter);
				}
			}
		} else{
				echo('</br>No matches found');
		}
	}



?>
