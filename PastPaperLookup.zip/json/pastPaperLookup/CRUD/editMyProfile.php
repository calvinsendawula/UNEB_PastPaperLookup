<?php include('../TEMPLATES/dashboardOpening.php');
  include('../DB/dbMethods.php');
  $varUserID = $_SESSION['UserID'];
  $sql="SELECT * FROM tbl_client where clientID = '".$varUserID."'";
  $result = getData($sql);
  if(count($result) != 0){
    $varUID = $result["clientID"];
    $varFName = $result["clientFName"];
    $varLName = $result["clientLName"];
    $varUName = $result["clientUName"];
    $varPhone = $result["clientPhone"];
    $varEmail = $result["clientEmail"];
    $varLocation = $result["clientLocation"];
  }
?>
<div class="home-content">
  <div class="sales-boxes">
    <div class="recent-sales box">
      <form method="post" action="../DB/updateMyProfile.php">
        <div class="row">
          <!--<div class="col-3 text-center">
            <img src="../IMAGES/male-user.png" class="img-fluid my-3 male-user-icon" alt="User image">
            <a class="btn btn-outline-success" href="#" role="button">
              <i class="far fa-edit">&nbsp;Edit Picture</i>
            </a>
          </div>-->
          <div class="col-12 float-left">
            <div class="title">
              <big>Edit Details</big>
            </div>
            <div class="form-group">
              <label for="exampleInputPassword1">Username</label>
              <input type="text" class="form-control" id="exampleInputPassword1" value="<?php echo($varUName); ?>" name="username" required>
            </div>
            <div class="form-group">
              <label for="exampleInputEmail1">Email address</label>
              <input type="email" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" value="<?php echo($varEmail); ?>" name="email" required>
              <small id="emailHelp" class="form-text text-muted">We'll never share your email with anyone else.</small>
            </div>
          </div>
        </div>
        <div class="row">
          <div class="col-12 form-group">
            <label for="exampleInputPassword1">Phone</label>
            <input type="text" class="form-control" id="exampleInputPassword1" value="<?php echo($varPhone); ?>" name="phone" required>
          </div>
          <div class="col-12 form-group">
            <label for="exampleInputPassword1">Address</label>
            <input type="text" class="form-control" id="exampleInputPassword1" value="<?php echo($varLocation); ?>" name="location" required>
          </div>
          <div class="col-12 form-group">
            <label for="exampleInputPassword1">New Password</label>
            <input type="password" class="form-control" id="exampleInputPassword1" placeholder="Password" name="new_password" required>
          </div>
          <div class="col-12 form-group">
            <label for="exampleInputPassword1">Confirm New Password</label>
            <input type="password" class="form-control" id="exampleInputPassword1" placeholder="Password" name="confirm_new_password" required>
          </div>
          <div class="col-12">
            <button class="btn btn-outline-danger" type="button" onclick="window.location.href='../DASHBOARD/myProfile.php'" name="button"><i class="fas fa-arrow-left"></i>&emsp;Cancel</button>&emsp;
            <input class="btn btn-outline-success text-center" role="button" id="submit-button" type="submit"></input>
          </div>
        </div>
      </form>
    </div>
  </div>
</div><br>
<?php include('../TEMPLATES/dashboardClosing.php'); ?>
