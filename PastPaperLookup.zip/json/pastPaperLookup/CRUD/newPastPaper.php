<?php include('../TEMPLATES/dashboardOpening.php'); ?>
    <div class="home-content">
      <div class="sales-boxes">
        <div class="recent-sales box">
          <div class="row">
            <div class="col-12 float-left">
              <div class="row my-3">
                <div class="col title text-center">
                  <big>NEW PAST PAPER</big>
                </div>
              </div>
              <div class="row my-3">
                <form class="container" method="post" action="../QUERY/processNewPastPaper.php">
                  <div class="form-group row">
                    <div class="col-3 my-2">
                      <label for="pastPaperSubjectCode">Subject Code</label>
                    </div>
                    <div class="col-3">
                      <input type="number" class="form-control" placeholder="e.g 101" name="pastPaperSubjectCode" required>
                    </div>
                  </div>
                  <div class="form-group row">
                    <div class="col-3 my-2">
                      <label for="pastPaperIssuer">Issuing Body</label>
                    </div>
                    <div class="col-3">
                      <select class="btn btn-secondary form-control" name="pastPaperIssuer" required>
                        <option value="UNEB">UNEB</option>
                        <option value="WAKISSHA">WAKISSHA</option>
                      </select>
                    </div>
                  </div>
                  <div class="form-group row">
                    <div class="col-3 my-2">
                      <label for="pastPaperNumber">Paper Number</label>
                    </div>
                    <div class="col-2">
                      <select class="btn btn-secondary form-control" name="pastPaperNumber" required>
                        <option value="1">1</option>
                        <option value="2">2</option>
                        <option value="3">3</option>
                        <option value="4">4</option>
                        <option value="5">5</option>
                        <option value="6">6</option>
                      </select>
                    </div>
                  </div>
                  <div class="form-group row">
                    <div class="col-3 my-2">
                      <label for="pastPaperYearSat">Year Sat</label>
                    </div>
                    <div class="col-2">
                      <select class="btn btn-secondary form-control" name="pastPaperYearSat" required>
                        <option value="2021">2021</option>
                        <option value="2020">2020</option>
                        <option value="2019">2019</option>
                        <option value="2018">2018</option>
                        <option value="2017">2017</option>
                        <option value="2016">2016</option>
                        <option value="2015">2015</option>
                        <option value="2014">2014</option>
                        <option value="2013">2013</option>
                        <option value="2012">2012</option>
                        <option value="2011">2011</option>
                        <option value="2010">2010</option>
                        <option value="2009">2009</option>
                        <option value="2008">2008</option>
                        <option value="2007">2007</option>
                        <option value="2006">2006</option>
                        <option value="2005">2005</option>
                        <option value="2004">2004</option>
                        <option value="2003">2003</option>
                        <option value="2002">2002</option>
                        <option value="2001">2001</option>
                        <option value="2000">2000</option>
                      </select>
                    </div>
                  </div>
                  <div class="form-group row">
                    <div class="col-3 my-2">
                      <label for="pastPaperNumberOfCopies">Number of Copies</label>
                    </div>
                    <div class="col-9">
                      <input type="number" class="form-control" placeholder="Leave blank if uncounted" name="pastPaperNumberOfCopies">
                    </div>
                  </div>
                  <div class="row">
                    <div class="col-12">
                      <button class="btn btn-outline-danger" type="button" onclick="window.location.href='../DASHBOARD/new.php'" name="button"><i class="fas fa-arrow-left"></i>&emsp;Cancel</button>&emsp;
                      <input class="btn btn-outline-success text-center" role="button" id="submit-button" type="submit"></input>
                    </div>
                  </div>
                </form>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
<?php include('../TEMPLATES/dashboardClosing.php'); ?>
