<?php include('../TEMPLATES/dashboardOpening.php'); ?>
    <div class="home-content">
      <div class="sales-boxes">
        <div class="recent-sales box">
          <div class="row">
            <div class="col-12 float-left">
              <div class="row my-3">
                <div class="col title text-center">
                  <big>SEARCH THE DATABASE</big>
                </div>
              </div>
              <div class="row my-3">
                <div class="col-6 text-center">
                  <img id="gif-icons" type="button" onclick="window.location.href='../AJAX/searchByName.php'" src="../GIFS/icons8-alphabetical-sorting.gif">
                  <p>Search by name</p>
                </div>
                <div class="col-6 text-center">
                  <img id="gif-icons" type="button" onclick="window.location.href='../AJAX/searchByPaperCode.php'" src="../GIFS/icons8-counter.gif">
                  <p>Search by paper code</p>
                </div>
              </div>
              <div class="row my-3">
                <div class="col-6 text-center">
                  <img id="gif-icons" type="button" onclick="window.location.href='../AJAX/searchByNameAndPaperNumber.php'" src="../GIFS/icons8-list.gif">
                  <p>Search by name </br>and paper number</p>
                </div>
                <div class="col-6 text-center">
                  <img id="gif-icons" type="button" onclick="window.location.href='../AJAX/searchByYearSat.php'" src="../GIFS/icons8-calendar.gif">
                  <p>Search by year sat</p>
                </div>
              </div>
              <div class="row my-3">
                <div class="col-6 text-center">
                  <button id="gif-icons" style="color: black;" class="btn btn-outline-secondary" type="button" onclick="window.location.href='../AJAX/searchByIssuer.php'" name="button"><big><i class="fas fa-building"></i>&emsp;UNEB / WAKISSHA</big></button>
                  <p>Search by issuer</p>
                </div>
                <div class="col-6 text-center">
                  <button id="gif-icons" style="color: black;" class="btn btn-outline-secondary" type="button" onclick="window.location.href='../AJAX/searchByEducationLevel.php'" name="button"><big><i class="fas fa-school"></i>&emsp;UACE / UCE</big></button>
                  <p>Search by Education Level</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
<?php include('../TEMPLATES/dashboardClosing.php'); ?>
