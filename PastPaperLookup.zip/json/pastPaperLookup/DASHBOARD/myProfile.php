<?php include('../TEMPLATES/dashboardOpening.php');
  include('../DB/dbMethods.php');
  $varUserID = $_SESSION['UserID'];
  $sql="SELECT * FROM tbl_client where clientID = '".$varUserID."'";
  $result = getData($sql);
  if(count($result) != 0){
    $varUID = $result["clientID"];
    $varFName = $result["clientFName"];
    $varLName = $result["clientLName"];
    $varUName = $result["clientUName"];
    $varPhone = $result["clientPhone"];
    $varEmail = $result["clientEmail"];
    $varLocation = $result["clientLocation"];
  }
?>
<div class="home-content">
      <div class="sales-boxes">
        <div class="recent-sales box">
          <div class="row">
            <div class="col-12 float-left">
              <div class="row my-3">
                <div class="col-7 title">
                  <big><?php echo($varFName.' '.$varLName); ?></big>
                </div>
                <div class="col-5">
                  <a class="btn btn-outline-success" href="../CRUD/editMyProfile.php" role="button">
                    <i class="far fa-edit">&nbsp;Edit Details</i>
                  </a>
                </div>
              </div>
              <div class="row my-3">
                <div class="col-3">
                  <strong>Username</strong>
                </div>
                <div class="col-6 float-left">
                  <?php echo($varUName); ?>
                </div>
              </div>
              <div class="row my-3">
                <div class="col-3">
                  <strong>Email</strong>
                </div>
                <div class="col-6 float-left">
                  <?php echo($varEmail); ?>
                </div>
              </div>
              <div class="row my-3">
                <div class="col-3">
                  <strong>Phone</strong>
                </div>
                <div class="col-6 float-left">
                  <?php echo($varPhone); ?>
                </div>
              </div>
              <div class="row my-3">
                <div class="col-3">
                  <strong>Address</strong>
                </div>
                <div class="col-6 float-left">
                  <?php echo($varLocation); ?>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
<?php include('../TEMPLATES/dashboardClosing.php'); ?>
