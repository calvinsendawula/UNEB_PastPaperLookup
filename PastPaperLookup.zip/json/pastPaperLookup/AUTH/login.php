<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
	<link rel="stylesheet" type="text/css" href="../CSS/userStyles.css">
	<title>Login</title>
</head>
<body>
	<div class="view" style="background-image: url('../IMAGES/loginBackground.jpg');
		-webkit-background-size: cover;
		-moz-background-size: cover;
		-o-background-size: cover;
		background-size: cover;">
	<div class="row">
		<div class="col-6">
		</div>
		<div class="col-6">
		<form class="g-3" id="inputform" action="../AUTH/processLogin.php" method="POST">
			<div class="container">
				<h2 style="text-align: center; color: blue;">PAST PAPER LOOKUP</h2>
				<h3 style="text-align: center;">SIGN IN</h3>
				<div class="mb-3">
					<label for="Username" class="form-label">Username</label>
					<input type="text" class="form-control" name="username" id="username" placeholder="Enter Username" required>
				<br>

					<label for="password" class="form-label">Password</label>
					<input type="password" class="form-control" name="password" id="password" placeholder="Enter password" required>
				<br>

					<div class="col-12 offset-md-2 justify-content-center">
						<button type="submit" class="btn btn-success">Sign in</button><br>
						<!--<span style="color:white;">Don't have an account? </span>
						<button type="button" class="btn btn-light"><a href="../FRONT/register.php" style="text-decoration: none;">Register</a></button><br>-->
					</br>
					</div>
				</div>
			</form>
		</div>
	</div>
	<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>
</body>
</html>
