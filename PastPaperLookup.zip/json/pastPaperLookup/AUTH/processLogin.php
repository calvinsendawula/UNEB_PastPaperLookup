<?php
session_start();
require_once("../DB/dbMethods.php");

$varUsername = $_POST['username'];
$varPassword = $_POST['password'];

verifyUser($varUsername,$varPassword);

 ?>
