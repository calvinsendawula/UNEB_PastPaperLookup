<?php

//For tips and tricks, see '../Db/phpTips.php'
//NOTE: to specify port number, see 'dbPortInfo' method.

function dbPortInfo(){
	$dbport = "3306"; //Can be specified according to Developer's preferred or available port.
	return ($dbport);
}

function connect(){
	$dbserver = "localhost";
	$dbuser = "root";
	$dbpass = "";
	$dbname = "travelagency";
	$dbport = dbPortInfo(); //Can be specified according to Developer's preferred or available port.
	$link=mysqli_connect($dbserver,$dbuser,$dbpass,$dbname,$dbport) or die("Could not connect".mysqli_connect_error());
	return ($link);
}

function setData($sql){
	$link=connect();
	if (mysqli_query($link,$sql)) {
	/*	echo("<script>
			alert('Data inserted successfully.');
			</script>");*/
		return true;
	} else {
		//echo("Error".mysqli_error($link));
		echo("<script>
			alert('Error '".mysqli_error($link).");
			</script>");
		return false;
	}
}

function getData($sql){
	$link=connect();
	$result=mysqli_query($link,$sql);
	#$rows = array();
	while ($row=mysqli_fetch_array($result,MYSQLI_ASSOC)) {
		$rows=$row;
		return $rows;
	}
	#return $rows;
}

function getDataRows($sql){
	$link=connect();
	$result=mysqli_query($link,$sql);
	while ($row=mysqli_fetch_array($result,MYSQLI_ASSOC)) {
		$rows[]=$row;
	}
	return $rows;
}

function createCookie($cookieName,$cookieContent){
	$expiretime = time() + 60*60*3; //expires after 3 hours
	setcookie($cookieName, $cookieContent, $expiretime);
}

function destroyCookie($cookieName){
	$expired = time() -1;
	setcookie($cookieName, "", $expired);
}

function verifyUser($varUsername, $varPassword){
	$dbserver = "localhost";
	$dbuser = "root";
	$dbpass = "";
	$dbname = "travelagency";
	$dbport = dbPortInfo(); //Can be specified according to Developer's preferred or available port.
	$conn = new mysqli($dbserver,$dbuser,$dbpass,$dbname,$dbport);

	$sql="SELECT * FROM tbl_client where clientUName = '".$varUsername."'";
	$result= $conn->query($sql);
	if (mysqli_num_rows($result)==0) {
		$sql="SELECT * FROM tbl_admin where adminUName = '".$varUsername."'";
		$result= $conn->query($sql);
		if (mysqli_num_rows($result)==0) {
			echo '<script>alert("User not found! Try logging in again.");
			window.location.href = "../AUTH/login.php";</script>';
		} else{
			while($res = mysqli_fetch_array($result)) {
				$hashedPass = $res['adminPassword'];
				$verify = password_verify($varPassword, $hashedPass);
			  	if ($verify) {
					$_SESSION['User']=$res['adminUName'];
					$_SESSION['UserID']=$res['adminID'];
					$_SESSION['UserFName']=$res['adminFName'];
					echo("<script>
						alert('Login Successful');
						window.location.href='../DASHBOARD/dashboard.php';
						</script>");
			  	} else {
			  		echo("<script>
						alert('Please check your info and try again.');
						window.location.href='../AUTH/login.php';
						</script>");
			  	}
			}
		}
	} else{
		while($res = mysqli_fetch_array($result)) {
			$hashedPass = $res['clientPassword'];
			$verify = password_verify($varPassword, $hashedPass);
		  	if ($verify) {
				$_SESSION['User']=$res['clientUName'];
				$_SESSION['UserID']=$res['clientID'];
				$_SESSION['UserFName']=$res['clientFName'];

				$varUID = $res['clientID'];
				$logBool = 'true';
				$sql_update = "UPDATE tbl_client SET logStatus = '$logBool' WHERE clientID=$varUID" ;
			  setData($sql_update);

				echo("<script>
					alert('Login Successful');
					window.location.href='../DASHBOARD/dashboard.php';
					</script>");
		  	} else {
		  		echo("<script>
					alert('Please check your info and try again.');
					window.location.href='../AUTH/login.php';
					</script>");
		  	}
		}
	}
}
 ?>
