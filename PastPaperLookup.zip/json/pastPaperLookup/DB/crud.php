<?php
  include('../DB/phpMethods.php');

  function insertNewCategory($varPastPaperName,$varPastPaperIssuer,$varPastPaperEducationLevel,$varPastPaperCode){
  $dbserver = "localhost";
	$dbuser = "root";
	$dbpass = "";
	$dbname = "pastpaperlookup";
	$dbport = dbPortInfo(); //Can be specified according to Developer's preferred or available port.
	$conn = new mysqli($dbserver,$dbuser,$dbpass,$dbname,$dbport);
    $sql="SELECT * FROM tbl_past_paper_category where
      pastPaperCode = '".$varPastPaperCode."'";
  	$result= $conn->query($sql);
  	if (mysqli_num_rows($result)==0){
      $sql_insert = "INSERT INTO      tbl_past_paper_category(pastPaperName,pastPaperIssuer,pastPaperLevelOfEducation,pastPaperCode)
      VALUES('$varPastPaperName','$varPastPaperIssuer','$varPastPaperEducationLevel','$varPastPaperCode')";
      setdata($sql_insert);
      $displayMessage = "$varPastPaperIssuer - $varPastPaperEducationLevel - $varPastPaperName - $varPastPaperCode has been added successfully";
      echo("<script>
        alert('$displayMessage');
        window.location.href='../CRUD/newCategory.php';
        </script>");
    } else{
      $sql="SELECT * FROM tbl_past_paper_category where
        pastPaperIssuer = '".$varPastPaperIssuer."'";
    	$result= $conn->query($sql);
    	if (mysqli_num_rows($result)==0){
        $sql_insert = "INSERT INTO      tbl_past_paper_category(pastPaperName,pastPaperIssuer,pastPaperLevelOfEducation,pastPaperCode)
        VALUES('$varPastPaperName','$varPastPaperIssuer','$varPastPaperEducationLevel','$varPastPaperCode')";
        setdata($sql_insert);
        $displayMessage = "$varPastPaperIssuer - $varPastPaperEducationLevel - $varPastPaperName - $varPastPaperCode has been added successfully";
        echo("<script>
          alert('$displayMessage');
          window.location.href='../CRUD/newCategory.php';
          </script>");
      } else{
        $displayMessage = "Past paper Category $varPastPaperIssuer - $varPastPaperCode already exists";
        echo("<script>
          alert('$displayMessage');
          window.location.href='../CRUD/newCategory.php';
          </script>");
      }
    }
  }

  function insertNewPastPaper($varPastPaperSubjectCode,$varPastPaperIssuer,$varPastPaperNumber,$varPastPaperYearSat,$varPastPaperNumberOfCopies){
  $dbserver = "localhost";
	$dbuser = "root";
	$dbpass = "";
	$dbname = "pastpaperlookup";
	$dbport = dbPortInfo(); //Can be specified according to Developer's preferred or available port.
	$conn = new mysqli($dbserver,$dbuser,$dbpass,$dbname,$dbport);
    $sql="SELECT * FROM tbl_past_paper_category where
      pastPaperCode = '".$varPastPaperSubjectCode."'";
  	$result= $conn->query($sql);
  	if (mysqli_num_rows($result)!=0){
      $sql="SELECT * FROM tbl_past_paper_category where
        pastPaperIssuer = '".$varPastPaperIssuer."'";
    	$result= $conn->query($sql);
    	if (mysqli_num_rows($result)!=0){
        $sql = "SELECT categoryID
          FROM tbl_past_paper_category
          WHERE pastPaperCode = '".$varPastPaperSubjectCode."'";
        $result= $conn->query($sql);
      	if (mysqli_num_rows($result)!=0){
          while($res = mysqli_fetch_array($result)) {
  					$varCategoryID=$res['categoryID'];
          }
        $sql = "SELECT *
          FROM tbl_past_paper
          WHERE pastPaperYearSat = $varPastPaperYearSat AND categoryID = '".$varCategoryID."'";
        $result= $conn->query($sql);
      	if (mysqli_num_rows($result)==0){
          if ($varPastPaperNumberOfCopies>1) {
            $displayMessage = "$varPastPaperSubjectCode - $varPastPaperNumber - $varPastPaperYearSat - has been added successfully with $varPastPaperNumberOfCopies copies";
          } else{
            $varPastPaperNumberOfCopies = 1;
            $displayMessage = "$varPastPaperSubjectCode - $varPastPaperNumber - $varPastPaperYearSat - has been added successfully with $varPastPaperNumberOfCopies copy";
          }
          $sql_insert = "INSERT INTO tbl_past_paper(categoryID,pastPaperNumber,pastPaperYearSat,pastPaperNumberOfCopies)
      		VALUES('$varCategoryID','$varPastPaperNumber','$varPastPaperYearSat','$varPastPaperNumberOfCopies')";
          setdata($sql_insert);
          echo("<script>
            alert('$displayMessage');
            window.location.href='../CRUD/newPastPaper.php';
            </script>");
        } else{
          echo("<script>
            alert('duplicate');
            window.location.href='../CRUD/newPastPaper.php';
            </script>");
        }
        /*$sql = "SELECT categoryID
          FROM tbl_past_paper_category
          WHERE pastPaperCode = '".$varPastPaperSubjectCode."'";
        $result= $conn->query($sql);
      	if (mysqli_num_rows($result)!=0){
          while($res = mysqli_fetch_array($result)) {
  					$varCategoryID=$res['categoryID'];
          }
          if ($varPastPaperNumberOfCopies>1) {
            $displayMessage = "$varPastPaperSubjectCode - $varPastPaperNumber - $varPastPaperYearSat - has been added successfully with $varPastPaperNumberOfCopies copies";
          } else{
            $varPastPaperNumberOfCopies = 1;
            $displayMessage = "$varPastPaperSubjectCode - $varPastPaperNumber - $varPastPaperYearSat - has been added successfully with $varPastPaperNumberOfCopies copy";
          }
          $sql_insert = "INSERT INTO tbl_past_paper(categoryID,pastPaperNumber,pastPaperYearSat,pastPaperNumberOfCopies)
      		VALUES('$varCategoryID','$varPastPaperNumber','$varPastPaperYearSat','$varPastPaperNumberOfCopies')";
          setdata($sql_insert);
          echo("<script>
            alert('$displayMessage');
            window.location.href='../CRUD/newPastPaper.php';
            </script>");
        }*/
      } else{
        $displayMessage = "Past paper $varPastPaperSubjectCode - $varPastPaperYearSat already exists";
        echo("<script>
          alert('$displayMessage');
          window.location.href='../CRUD/newPastPaper.php';
          </script>");
      }
    } else{
      $displayMessage = "Past paper $varPastPaperSubjectCode - $varPastPaperYearSat already exists";
      echo("<script>
        alert('$displayMessage');
        window.location.href='../CRUD/newPastPaper.php';
        </script>");
    } }
  }

  /*function insertNewPastPaper($varPastPaperSubjectCode,$varPastPaperIssuer,$varPastPaperNumber,$varPastPaperYearSat,$varPastPaperNumberOfCopies){
    $existCheck = checkIfExistsPastPaper($varPastPaperSubjectCode,$varPastPaperNumber,$varPastPaperYearSat,$varPastPaperNumberOfCopies);
    if (!empty($existCheck)) {
      $displayMessage = "Past paper $varPastPaperCode - $varPastPaperYearSat already exists";
      echo("<script>
        alert('$displayMessage');
        window.location.href='../CRUD/newPastPaper.php';
        </script>");
    } else{
      $varCategoryID = retrieveCategoryID($varPastPaperSubjectCode);
      $sql_insert = "INSERT INTO tbl_past_paper(categoryID,pastPaperNumber,pastPaperYearSat,pastPaperNumberOfCopies)
  		VALUES('$varCategoryID','$varPastPaperNumber','$varPastPaperYearSat','$varPastPaperNumberOfCopies')";
      setdata($sql_insert);
      if ($varPastPaperNumberOfCopies>1) {
        $displayMessage = "$varPastPaperSubjectCode - $varPastPaperNumber - $varPastPaperYearSat - has been added successfully with $varPastPaperNumberOfCopies copies";
      } else{
        $displayMessage = "$varPastPaperSubjectCode - $varPastPaperNumber - $varPastPaperYearSat - has been added successfully with $varPastPaperNumberOfCopies copy";
      }
      echo("<script>
        alert('$displayMessage');
        window.location.href='../CRUD/newPastPaper.php';
        </script>");
    }
  }*/

  function retrieveCategoryID($pastPaperCode){
    $sql = "SELECT categoryID
      FROM tbl_past_paper_category
      WHERE pastPaperCode = '".$pastPaperCode."'";
    getdata($sql);
  }

  function retrievePastPaperID($pastPaperCode){
    $categoryID = retrieveCategoryID($pastPaperCode);
    $sql = "SELECT * FROM tbl_past_paper
      WHERE categoryID = $categoryID";
    getdata($sql);
  }

  function checkIfExistsPastPaper($varPastPaperSubjectCode,$varPastPaperNumber,$varPastPaperYearSat,$varPastPaperNumberOfCopies){
    $categoryID = retrieveCategoryID($varPastPaperSubjectCode);
    $sql = "SELECT * FROM tbl_past_paper
      WHERE categoryID = $categoryID";
    getdata($sql);
  }

  function updateCategory($pastPaperName,$pastPaperIssuer,$pastPaperLevelOfEducation,$pastPaperCode){
    $categoryID = $_COOKIE['categoryID'];
    $sql_update = "UPDATE tbl_past_paper_category
      SET pastPaperName = $pastPaperName, pastPaperCode = $pastPaperCode,
          pastPaperIssuer = $pastPaperIssuer, pastPaperLevelOfEducation = $pastPaperLevelOfEducation
      WHERE categoryID=$categoryID" ;
    setData($sql_update);
    $displayMessage = $pastPaperIssuer.' - '.$pastPaperName.' - '.$pastPaperCode.' - '.$pastPaperLevelOfEducation.' has been updated successfully';
    destroyCookie($categoryID);
    echo("<script>
      window.location.href='../DASHBOARD/allCategories.php';
      alert('$displayMessage');
      </script>");
  }

  function updatePastPaper($pastPaperCode,$pastPaperNumber,$pastPaperYearSat){
    $pastPaperID = retrievePastPaperID($pastPaperCode);
    $categoryID = retrieveCategoryID($pastPaperCode);
    # $pastPaperID = $_COOKIE['pastPaperID'];
    $sql_update = "UPDATE tbl_past_paper
      SET categoryID = $categoryID,
        pastPaperNumber = $pastPaperNumber,
        pastPaperYearSat = $pastPaperYearSat,
        pastPaperNumberOfCopies = $pastPaperNumberOfCopies
      WHERE pastPaperID=$pastPaperID" ;
    setData($sql_update);
    $displayMessage = 'Update has been made successfully';
    echo("<script>
      window.location.href='../DASHBOARD/allPastPapers.php';
      alert('$displayMessage');
      </script>");
  }

 ?>
