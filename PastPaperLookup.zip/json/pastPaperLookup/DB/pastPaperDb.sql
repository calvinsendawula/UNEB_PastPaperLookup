/**************************************** Table 1 **************************************************/
CREATE TABLE IF NOT EXISTS `tbl_past_paper_category` (
    `categoryID` INT(8) AUTO_INCREMENT NOT NULL,
    `pastPaperName` VARCHAR(255) NOT NULL,
    `pastPaperIssuer` ENUM('WAKISSHA','UNEB') NOT NULL,
    `pastPaperLevelOfEducation` ENUM('UACE','UCE') NOT NULL,
    `pastPaperCode` INT(3) NOT NULL,
    PRIMARY KEY(`categoryID`)
);

ALTER TABLE `tbl_past_paper_category` AUTO_INCREMENT=40313080;

/**************************************** Table 2 **************************************************/
CREATE TABLE IF NOT EXISTS `tbl_past_paper` (
    `pastPaperID` INT(8) AUTO_INCREMENT NOT NULL,
    `categoryID` INT(8) NOT NULL,
    `pastPaperNumber` ENUM('1','2','3','4','5','6') NOT NULL,
    `pastPaperYearSat` INT(4) NOT NULL,
    `pastPaperNumberOfCopies` INT(4) DEFAULT 1 NOT NULL,
    PRIMARY KEY(`pastPaperID`),
    FOREIGN KEY(`categoryID`) REFERENCES `tbl_past_paper_category`(`categoryID`)
);

ALTER TABLE `tbl_past_paper` AUTO_INCREMENT=74965370;
