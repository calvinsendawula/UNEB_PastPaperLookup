<?php
  include('../DB/phpMethods.php');

  function insertNewCategory($varPastPaperName,$varPastPaperIssuer,$varPastPaperEducationLevel,$varPastPaperCode){
    $sql="SELECT * FROM tbl_past_paper_category where
      pastPaperCode = '".$varPastPaperCode."'";
  	if (getData($sql)==0){
      $sql_insert = "INSERT INTO      tbl_past_paper_category(pastPaperName,pastPaperIssuer,pastPaperLevelOfEducation,pastPaperCode)
      VALUES('$varPastPaperName','$varPastPaperIssuer','$varPastPaperEducationLevel','$varPastPaperCode')";
      setdata($sql_insert);
      $displayMessage = "$varPastPaperIssuer - $varPastPaperEducationLevel - $varPastPaperName - $varPastPaperCode has been added successfully";
      echo("<script>
        alert('$displayMessage');
        window.location.href='../CRUD/newCategory.php';
        </script>");
    } else{
      $sql="SELECT * FROM tbl_past_paper_category where
        pastPaperIssuer = '".$varPastPaperIssuer."'";
    	$result= $conn->query($sql);
    	if (mysqli_num_rows($result)==0){
        $sql_insert = "INSERT INTO      tbl_past_paper_category(pastPaperName,pastPaperIssuer,pastPaperLevelOfEducation,pastPaperCode)
        VALUES('$varPastPaperName','$varPastPaperIssuer','$varPastPaperEducationLevel','$varPastPaperCode')";
        setdata($sql_insert);
        $displayMessage = "$varPastPaperIssuer - $varPastPaperEducationLevel - $varPastPaperName - $varPastPaperCode has been added successfully";
        echo("<script>
          alert('$displayMessage');
          window.location.href='../CRUD/newCategory.php';
          </script>");
      } else{
        $displayMessage = "Past paper Category $varPastPaperIssuer - $varPastPaperCode already exists";
        echo("<script>
          alert('$displayMessage');
          window.location.href='../CRUD/newCategory.php';
          </script>");
      }
    }
  }

 ?>
