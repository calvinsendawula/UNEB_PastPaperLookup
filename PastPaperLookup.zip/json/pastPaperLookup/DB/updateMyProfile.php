<?php
session_start();
require_once("dbMethods.php");

$varUserID = $_SESSION['UserID'];
$varUsername = $_POST['username'];
$varEmail = $_POST['email'];
$varPhone = $_POST['phone'];
$varLocation = $_POST['location'];
$varNewPassword = $_POST['new_password'];
$varConfirmPassword = $_POST['confirm_new_password'];

$hashedPass = password_hash($varConfirmPassword,PASSWORD_DEFAULT);

if(!empty($_POST['username']) &&
		!empty($_POST['email']) &&
			!empty($_POST['phone']) &&
				!empty($_POST['location']) &&
					!empty($_POST['new_password']) &&
						!empty($_POST['confirm_new_password'])){
							if(($_POST['new_password']) === ($_POST['confirm_new_password'])){
								//Updating data
								$sql_update = "UPDATE tbl_client SET clientUName = '$varUsername',
									clientEmail = '$varEmail', clientPhone = '$varPhone', clientLocation = '$varLocation',
									clientPassword = '$hashedPass' WHERE clientID = '$varUserID'";
								setData($sql_update);
								echo("<script>
								alert('Data updated successfully.');
								window.location.href='../DASHBOARD/dashboard.php';
								</script>");
							}else{
								echo("<script>
									alert('Password mismatch!');
									window.location.href='../CRUD/editMyProfile.php';
									</script>");
							}
} else{
	echo("<script>
		alert('Please check your info and try again.');
		</script>");
}
 ?>
