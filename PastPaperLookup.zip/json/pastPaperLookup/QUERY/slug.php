<?php include('../TEMPLATES/dashboardOpening.php'); ?>
    <div class="home-content">
      <div class="sales-boxes">
        <div class="recent-sales box">
          <div class="row">
            <div class="col-12 float-left">
              <div class="row my-3">
                <div class="col title text-center">
                  <big>DISPLAYING SLUG CONTENT</big>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
<?php include('../TEMPLATES/dashboardClosing.php'); ?>
