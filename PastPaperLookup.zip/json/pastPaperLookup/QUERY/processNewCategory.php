<?php
session_start();
require_once("../DB/crud.php");

$varPastPaperName = $_POST['pastPaperName'];
$varPastPaperIssuer = $_POST['pastPaperIssuer'];
$varPastPaperEducationLevel = $_POST['pastPaperEducationLevel'];
$varPastPaperCode = $_POST['pastPaperCode'];

insertNewCategory($varPastPaperName,$varPastPaperIssuer,$varPastPaperEducationLevel,$varPastPaperCode);

 ?>
