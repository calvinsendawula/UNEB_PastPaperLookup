<?php
session_start();
require_once("../DB/crud.php");

$varPastPaperSubjectCode = $_POST['pastPaperSubjectCode'];
$varPastPaperIssuer = $_POST['pastPaperIssuer'];
$varPastPaperNumber = $_POST['pastPaperNumber'];
$varPastPaperYearSat = $_POST['pastPaperYearSat'];
$varPastPaperNumberOfCopies = $_POST['pastPaperNumberOfCopies'];

insertNewPastPaper($varPastPaperSubjectCode,$varPastPaperIssuer,$varPastPaperNumber,$varPastPaperYearSat,$varPastPaperNumberOfCopies);

 ?>
