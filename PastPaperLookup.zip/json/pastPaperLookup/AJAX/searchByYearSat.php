<?php include('../TEMPLATES/dashboardOpening.php'); ?>
    <div class="home-content">
      <div class="sales-boxes">
        <div class="recent-sales box">
          <div class="row">
            <div class="col-12 float-left">
              <div class="row my-3">
                <div class="col title text-center">
                  <big>SEARCH BY YEAR SAT</big>
                </div>
              </div>
              <div class="row my-3">
                <form class="container" method="post" action="../DB/updateMyProfile.php">
                  <div class="form-group row">
                    <div class="col-3 my-2">
                      <label for="pastPaperSubjectName">Subject Name</label>
                    </div>
                    <div class="col-9">
                      <input type="text" class="form-control" placeholder="e.g History" name="pastPaperSubjectName" required>
                    </div>
                  </div>
                  <div class="form-group row">
                    <div class="col-3 my-2">
                      <label for="pastPaperYearSat">Year sat</label>
                    </div>
                    <div class="col-2">
                      <select class="btn btn-secondary form-control" name="pastPaperYearSat" required>
                        <option value="2021">2021</option>
                        <option value="2020">2020</option>
                        <option value="2019">2019</option>
                        <option value="2018">2018</option>
                        <option value="2017">2017</option>
                        <option value="2016">2016</option>
                        <option value="2015">2015</option>
                        <option value="2014">2014</option>
                        <option value="2013">2013</option>
                        <option value="2012">2012</option>
                        <option value="2011">2011</option>
                        <option value="2010">2010</option>
                        <option value="2009">2009</option>
                        <option value="2008">2008</option>
                        <option value="2007">2007</option>
                        <option value="2006">2006</option>
                        <option value="2005">2005</option>
                        <option value="2004">2004</option>
                        <option value="2003">2003</option>
                        <option value="2002">2002</option>
                        <option value="2001">2001</option>
                        <option value="2000">2000</option>
                      </select>
                    </div>
                  </div>
                  <div class="form-group row">
                    <div class="col-3 my-2">
                      <label for="pastPaperEducationLevel">Education Level</label>
                    </div>
                    <div class="col-2">
                      <select class="btn btn-secondary form-control" name="pastPaperEducationLevel" required>
                        <option value="UACE">UACE</option>
                        <option value="UCE">UCE</option>
                      </select>
                    </div>
                  </div>
                  <div class="row">
                    <div class="col-12">
                      <button class="btn btn-outline-danger" type="button" onclick="window.location.href='../DASHBOARD/search.php'" name="button"><i class="fas fa-arrow-left"></i>&emsp;Cancel</button>&emsp;
                      <input class="btn btn-outline-success text-center" role="button" id="submit-button" type="submit"></input>
                    </div>
                  </div>
                </form>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
<?php include('../TEMPLATES/dashboardClosing.php'); ?>
