<?php include('../TEMPLATES/dashboardOpening.php'); ?>
    <div class="home-content">
      <div class="sales-boxes">
        <div class="recent-sales box">
          <div class="row">
            <div class="col-12 float-left">
              <div class="row my-3">
                <div class="col title text-center">
                  <big>SEARCH BY ISSUER AND EDUCATION LEVEL</big>
                </div>
              </div>
              <div class="row my-3">
                <div class="col-6 text-center">
                  <button id="gif-icons" class="btn btn-outline-secondary" type="button" onclick="window.location.href='../VIEWALL/viewAllUACEUNEB.php'" name="button"><big><big>UNEB</br>A-Level</big></big></button>
                </div>
                <div class="col-6 text-center">
                  <button id="gif-icons" class="btn btn-outline-secondary" type="button" onclick="window.location.href='../VIEWALL/viewAllUCEUNEB.php'" name="button"><big><big>UNEB</br>O-Level</big></big></button>
                </div>
              </div>
              <div class="row my-3">
                <div class="col-6 text-center">
                  <button id="gif-icons" class="btn btn-outline-secondary" type="button" onclick="window.location.href='../VIEWALL/viewAllUACEWAKISSHA.php'" name="button"><big><big>WAKISSHA</br>A-Level</big></big></button>
                </div>
                <div class="col-6 text-center">
                  <button id="gif-icons" class="btn btn-outline-secondary" type="button" onclick="window.location.href='../VIEWALL/viewAllUCEWAKISSHA.php'" name="button"><big><big>WAKISSHA</br>O-Level</big></big></button>
                </div>
              </div>
              <div class="col-12">
                <button class="btn btn-outline-danger" type="button" onclick="window.location.href='../DASHBOARD/search.php'" name="button"><i class="fas fa-arrow-left"></i>&emsp;Cancel</button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
<?php include('../TEMPLATES/dashboardClosing.php'); ?>
