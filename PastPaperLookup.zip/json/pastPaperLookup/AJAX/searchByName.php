<?php include('../TEMPLATES/dashboardOpening.php'); ?>
    <div class="home-content">
      <div class="sales-boxes">
        <div class="recent-sales box">
          <div class="row">
            <div class="col-12 float-left">
              <div class="row my-3">
                <div class="col title text-center">
                  <big>SEARCH BY NAME</big>
                </div>
              </div>
              <div class="row my-3">
                <form class="container" method="post" action="../DB/updateMyProfile.php">
                  <div class="form-group row">
                    <div class="col-3 my-2">
                      <label for="pastPaperSubjectName">Subject Name</label>
                    </div>
                    <div class="col-9">
                      <input type="text" class="form-control" placeholder="e.g History" name="pastPaperSubjectName" required>
                    </div>
                  </div>
                  <div class="form-group row">
                    <div class="col-3 my-2">
                      <label for="pastPaperEducationLevel">Education Level</label>
                    </div>
                    <div class="col-2">
                      <select class="btn btn-secondary form-control" name="pastPaperEducationLevel" required>
                        <option value="UACE">UACE</option>
                        <option value="UCE">UCE</option>
                      </select>
                    </div>
                  </div>
                  <div class="row">
                    <div class="col-12">
                      <button class="btn btn-outline-danger" type="button" onclick="window.location.href='../DASHBOARD/search.php'" name="button"><i class="fas fa-arrow-left"></i>&emsp;Cancel</button>&emsp;
                      <input class="btn btn-outline-success text-center" role="button" id="submit-button" type="submit"></input>
                    </div>
                  </div>
                </form>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
<?php include('../TEMPLATES/dashboardClosing.php'); ?>
